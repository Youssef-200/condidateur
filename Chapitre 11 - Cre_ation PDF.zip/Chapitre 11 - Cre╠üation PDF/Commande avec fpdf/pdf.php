<?php
require('fpdf.php');



class PDF extends FPDF
{

function Header()
{
$this->Ln(10);
	global $titre;

	// Arial gras 15
	$this->SetFont('times','B',16);
	// Calcul de la largeur du titre et positionnement
	$w = $this->GetStringWidth($titre)+6;
	$this->SetX((210-$w)/2);
	// Couleurs du cadre, du fond et du texte
	
	$this->SetTextColor(220,50,50);
	
	// Titre
	$this->Cell($w,9,$titre,1,1,'C',false);
	// Saut de ligne
	$this->Ln(15);
}

function Footer()
{
	// Positionnement à 1,5 cm du bas
	$this->SetY(-15);
	// Arial italique 8
	$this->SetFont('times','',8);
	// Couleur du texte en gris
	$this->SetTextColor(128);
	// Numéro de page

	$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
}


function CorpsDocument($pneu,$huile,$bougies,$add,$total,$som,$date)
{
	$this->SetFont('times','',14);
	$this->SetLeftMargin(10);
	$this->SetFillColor(200,220,255);
	$this->Cell(0,5,"Bonjour Monsieur voila un recapitulatif de votre commande :  ",0,1,'L',true);
	$this->Ln(15);
	$this->SetFont('times','',12);
	$this->SetLeftMargin(20);
	$this->Cell(0,6, " * Commande traite le : $date.");
	$this->Ln(12);
	$this->Cell(0,6," * Nombre de pneu : $pneu.");
	$this->Ln(12);
	$this->Cell(0,6," * Nombre de bidons de huile : $huile.");
	$this->Ln(12);
	$this->Cell(0,6," * Nombre de bougies : $bougies.");
	$this->Ln(12);
	$this->Cell(0,6," * Votre Adresse : $add.");

	$this->Ln(30);
		$this->SetLeftMargin(150);
			$this->SetTextColor(30,127,203);
	$this->Cell(0,6," Total de commande : $som");
		$this->Ln(10);
					$this->SetTextColor(198,8,0);
	$this->Cell(0,6," Prix : $total DH.");
			$this->SetLeftMargin(70);
			$this->Image('font/signature-a.jpg',140,160,30);
			$this->Ln(75);
			$titre="Merci pour votre confiance a bientot";
			$w = $this->GetStringWidth($titre);
	$this->SetX((210-$w)/2);
	$this->SetFont('times','B',20);
					$this->SetDrawColor(0,80,180);
	$this->SetTextColor(220,50,50);
	// Epaisseur du cadre (1 mm)
	$this->SetLineWidth(1);
	// Titre
		$this->Ln(30);
	$this->Cell($w,9,$titre,0,0,'C',false);


	
	
}

function InsererDansPDF($pneu,$huile,$bougies,$add,$total,$som,$date)
{
	$this->AddPage();
	$this->CorpsDocument($pneu,$huile,$bougies,$add,$total,$som,$date);
}
}
if(isset($_POST['pneu']) && isset($_POST['huiles']) && isset($_POST['bougiess']) && isset($_POST['address'])){
$pneu=$_POST['pneu'];
$huile=$_POST['huiles'];
$bougies=$_POST['bougiess'];
$add=$_POST['address'];
$total=$_POST['total'];
$som=$_POST['somme'];
    $date = date('F d, Y');
$pdf = new PDF();
$titre = 'Le Garage de Karim vous souhaite la bienvenue : ';
$pdf->SetTitle($titre);
$pdf->InsererDansPDF($pneu,$huile,$bougies,$add,$total,$som,$date);
$pdf->Output();
}
?>
