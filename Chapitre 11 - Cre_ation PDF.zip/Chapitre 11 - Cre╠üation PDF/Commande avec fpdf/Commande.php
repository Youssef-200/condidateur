
<h1>Le garage de Karim </h1>
<h2>Resultats de la commande</h2>
<?php
if(isset($_POST['pneus']) && isset($_POST['huile']) && isset($_POST['bougie']) && isset($_POST['adr'])){
$qtPneu=$_POST['pneus'];
$qtHuile=$_POST['huile'];
$qtBougie=$_POST['bougie'];
$adr=$_POST['adr'];
$somme=$qtPneu+$qtHuile+$qtBougie;
echo "Commande traitee a ".date('G:i').", le ".date('w-n-Y')."<br>Recapitulatif de votre commande :<br> Articles commandes : ".$somme."<br><br>";
echo $qtPneu." pneus<br>";
echo $qtHuile." bidons d'huile<br>";
echo $qtBougie." bougies<br><br>";
$total=($qtPneu*100)+($qtHuile*10)+($qtBougie*4);
echo "Total de la commandes : ".$total.".00dhs;<br>";
echo "Adresse de livraison est : ".$adr;
?>
<form method="POST" action="pdf.php">
<input type="hidden" value="<?php echo $_POST['pneus']; ?>" name="pneu"/>
<input type="hidden" value="<?php echo $_POST['huile']; ?>" name="huiles"/>
<input type="hidden" value="<?php echo $_POST['bougie']; ?>" name="bougiess"/>
<input type="hidden" value="<?php echo $_POST['adr']; ?>" name="address"/>
<input type="hidden" value="<?php echo $total; ?>" name="total"/>
<input type="hidden" value="<?php echo $somme; ?>" name="somme"/>


<input type="image" src="font/PDF.jpg" height="40px" width="40px" border="0" value="generer un word"/>
</form>
<?php

}
?>